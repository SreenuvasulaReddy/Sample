//
//  CustomFont.h
//  CustomFont
//
//  Created by Sreeni on 19/02/24.
//

#import <Foundation/Foundation.h>

//! Project version number for CustomFont.
FOUNDATION_EXPORT double CustomFontVersionNumber;

//! Project version string for CustomFont.
FOUNDATION_EXPORT const unsigned char CustomFontVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <CustomFont/PublicHeader.h>


